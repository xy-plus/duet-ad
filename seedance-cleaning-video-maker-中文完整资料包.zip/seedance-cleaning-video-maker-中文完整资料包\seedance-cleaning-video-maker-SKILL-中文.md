---
name: seedance-cleaning-video-maker
description: 分析干净的、用户自有的、已获授权的或通用的 MP4、MOV、WebM 清洁类、前后对比类、产品演示类或短视频 UGC 参考素材；将其压缩为连贯的 15 秒结构；在避开字幕的同时提取最多 9 张按顺序排列的关键帧；编写与关键帧绑定的 Seedance 提示词；准备、确认、提交、轮询、下载，并在不进行生成后检查的情况下，立即返回一份未经修改的火山方舟 Seedance 2.0 结果。当用户希望复刻干净的参考视频、为 Seedance 缩短较长的混剪、选择其他爆款时刻，或通过 API 生成 Seedance 素材包和方舟原始视频时使用。此临时版本不会移除、替换、模糊或像素化第三方人物、商标、Logo 或受版权保护的美术作品。
---

# Seedance 清洁视频制作器

把清洁类参考视频转化为一套完整、可审阅的 15 秒 Seedance 素材包。所有描述都必须基于实际检查过的画面。绝不能根据文件名推测场景。

## 阅读相关参考资料

- 在选择最终关键帧或起草提示词之前，阅读 [references/prompt-and-compression.md](references/prompt-and-compression.md)。
- 在决定使用一个、两个还是三个场景时，阅读 [references/proven-patterns.md](references/proven-patterns.md)。
- 在构建、提交、轮询或诊断 API 请求之前，阅读 [references/ark-api.md](references/ark-api.md)。
- 在阶段 A 交付之前，以及阶段 B 提交之前，阅读 [references/qa-checklist.md](references/qa-checklist.md)。

## 遵循以下工作流程

### 1. 检查源视频

把源视频视为只读文件。此临时版本只用于用户声明为自有、已获授权、通用，或不存在可识别第三方人物、商标、Logo 和受版权保护美术作品的素材。如果常规检查发现明显的第三方元素，应停止并要求用户提供干净的源素材；此版本不得对其进行编辑、模糊、像素化、替换或净化处理。

确认源视频能够打开，然后记录时长、尺寸、方向、帧率、总帧数、文件大小；当可用探测工具能够识别时，还要记录是否存在音轨。

如果存在原生视频工具，优先使用。否则运行：

```powershell
python scripts/extract_keyframes.py <video> --out-dir <work-dir> --sample-count 40
```

检查密集抽帧联系表。对于快速混剪，将采样数量增加到 60–90 帧，或者围绕不明确的切镜提取精确时间点。在某一帧得到视觉检查之前，不得选择它作为关键帧。

### 2. 压缩为连贯的 15 秒

在决定保留哪些内容之前，先识别镜头边界并编写源视频时间线。优先保留完整的因果闭环：

`处理前状态 → 工具进入 → 主要施用动作 → 反应 → 擦拭/移除 → 最终结果`

删除字幕过多、带水印、运动模糊、处于转场混合状态、内容重复、短到无法展现结果，或与最强视觉故事无关的场景。

选择一种结构：

- 单场景：使用 9 个按顺序排列的动作状态，不切镜；
- 两个相关场景：第一段约分配 5 帧，第二段约分配 4 帧，中间只进行一次直接切镜；
- 三个高反差场景：每个场景分配 3 帧，共进行两次直接切镜，并保证每个场景都有完整的小闭环。

15 秒内不得超过三个场景。除非三个主体都具有极其清楚的处理前/动作/处理后反差，否则优先使用一个或两个场景。

### 3. 选择并导出最终关键帧

当用户要求 9 张关键帧时，应交付并提交恰好 9 张。为每张图片分配一个主要动作或状态。文件名必须按照 API 提交的时间顺序排列。

优先选择清晰、稳定、产品几何结构可见、手部遮挡较少且没有字幕的画面。不要只选择好看的结果画面；每个重要结果之前都必须有对应的原因画面。

导出精确 PNG：

```powershell
python scripts/extract_keyframes.py <video> `
  --out-dir <package>/keyframes `
  --times "0.33,1.66,2.33,3.55,4.15,4.55,7.66,8.32,8.85" `
  --prefix keyframe --columns 3
```

把生成的 `contact_sheet.jpg` 和 `manifest.json` 移动到素材包根目录。另行保留一份密集检查联系表。

### 4. 编写提示词

使用用户的语言编写。按照以下顺序组织：

1. 输出时长、画幅比例、分辨率和拍摄风格；
2. 图片1至图片9的精确作用；
3. 必须保持不变的主体、产品、环境和相机细节；
4. 总时长恰好为 15 秒的分时动作；
5. 物理因果关系；
6. 连贯性约束；
7. 简短的避免项列表。

让每张图片只驱动一个主要状态或动作。明确说明泡沫从喷嘴产生、痕迹只能在发生接触之后出现、洁净区域只能在擦拭工具经过之后推进。不要依赖负面提示词去修复相互矛盾的正向指令。

避免要求模型生成字幕或细小包装文字。只有在用户明确要求时，才在后期制作中添加准确文字。

### 5. 创建阶段 A 素材包

创建新的带版本文件夹，不要覆盖先前的生成结果：

```text
<video-stem>_seedance_package/
  keyframes/
  contact_sheet.jpg
  inspection_contact_sheet.jpg
  manifest.json
  shot_timeline.md
  seedance_prompt.txt
  api_request.json
  api_submission.md
```

在 `shot_timeline.md` 中写入源视频元数据、保留和删除的场景、每张关键帧的精确作用，以及最终 15 秒时间分配。将 `api_submission.md` 标记为 `PENDING_USER_CONFIRMATION`。

执行不产生费用的预检：

```powershell
python scripts/seedance_task.py create `
  --prompt-file <package>/seedance_prompt.txt `
  --ref-images <image-1> <image-2> <image-3> <image-4> <image-5> <image-6> <image-7> <image-8> <image-9> `
  --model doubao-seedance-2-0-260128 `
  --ratio 9:16 --duration 15 --resolution 720p `
  --generate-audio --no-watermark `
  --payload-out <package>/api_request.json --dry-run
```

核验请求中只有一个文本项、图片数量和顺序符合预期、提示词往返内容完全一致、参数正确，并且请求中不存在任何凭据。向用户展示相关文件并要求单独明确确认。本轮到此结束，不得联系方舟接口。

### 6. 只有收到新的确认后才能提交

即使准备请求中包含“一键生成”或“提交”等字样，也只能把它视为阶段 A。必须在最近一次预检之后，等待用户发送新的消息，例如“确认提交”。在确认后，如果提示词、参考图片、图片顺序、模型、时长、画幅比例、分辨率、音频设置、水印设置或任务数量发生任何实质变化，该确认即失效。

对于一个已经确认的任务，只能从 `ARK_API_KEY` 读取密钥，并运行：

```powershell
python scripts/seedance_task.py create `
  --prompt-file <package>/seedance_prompt.txt `
  --ref-images <image-1> <image-2> <image-3> <image-4> <image-5> <image-6> <image-7> <image-8> <image-9> `
  --model doubao-seedance-2-0-260128 `
  --ratio 9:16 --duration 15 --resolution 720p `
  --generate-audio --no-watermark --confirm-submit `
  --wait --state-file <package>/task.json `
  --download <package>/generated.mp4
```

绝不能在聊天、命令参数、Markdown、JSON、日志或源代码文件中接收、打印或存储 API Key。一次确认只授权创建一个经过审阅的任务。如果实时创建失败，未经新的授权不得再次创建第二个可能产生费用的任务。

### 7. 下载并立即交付原始结果

方舟返回 `succeeded` 后，立即把临时结果 URL 下载到 `<package>/generated.mp4`，然后把该文件返回给用户。

不得打开、播放、探测、检查、截图、采样、OCR、抽取生成视频的帧、为生成视频制作联系表，或以其他方式分析生成视频。不得进行生成后视觉 QA、字幕检查、场景检查、媒体元数据检查或哈希计算。方舟状态成功且下载完成，即为交付的终止条件。

将下载的 `generated.mp4` 逐字节保留为方舟/Seedance 原始视频。除非用户在收到原始视频后另行给出明确指令，否则不得对其进行模糊、像素化、遮罩、裁剪、截短、编辑、重新编码、重新封装或任何其他后期处理。如果之后根据单独请求制作衍生版本，必须使用不同文件名保存，且绝不能把衍生版本表述为 Seedance 原始视频。

更新 `api_submission.md` 时，只能写入任务响应已经返回的字段，例如任务 ID、最终状态、请求时长、画幅比例、分辨率、帧率、Seed、音频设置和下载文件名。不得读取视频来获取其他字段。应首先交付 `generated.mp4`，之后只附带简短的任务状态；生成视频联系表和生成后复查报告不属于最终交付内容。

## 安全处理失败情况

- 遇到身份验证错误时，确认环境中存在 `ARK_API_KEY` 且具有权限；绝不能要求用户在聊天中发送密钥。
- 遇到请求错误时，检查参考图数量、角色、媒体类型、时长、模型和请求大小。
- 遇到内容审核拒绝时，定位第一个失败的提示词或参考素材。如果原因涉及明显第三方元素，应停止并要求用户提供干净素材，因为此版本没有移除或净化流程。不得承诺绕过审核。
- 如果任务创建后本地轮询被中断，应使用 `seedance_task.py status <task-id> --wait` 恢复同一任务，不得创建替代任务。

## 最终约束

- 单个任务提交的图片不得超过 9 张。
- 保证图片1至图片9与 API 内容顺序一致。
- 保证原因先于结果，未处理区域不得提前变化。
- 保持交付素材包带版本且可复现。
- 把方舟下载的原始 `generated.mp4` 作为主要视频交付物返回。
- 下载成功后立即返回，不得检查或采样生成视频。
- 未经用户单独明确请求，绝不能对 Seedance 结果进行后期处理。
- 除非用户明确要求安装或修改，否则绝不能安装或修改此 Skill。
